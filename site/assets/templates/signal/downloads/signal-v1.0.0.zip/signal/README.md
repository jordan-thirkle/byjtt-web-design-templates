# Signal — v1.0.0

A template from ByJTT Web Design Templates for Agents / AI.

## Quick start
Open `index.html` in a browser, or serve the folder (`python3 -m http.server`) and edit any
file — this is plain HTML/CSS/JS with no build step.

## What's in the box
- The complete template site (`index.html`, `css/`, `js/`, `assets/`)
- `manifest.json` — the binding spec: every file, design tokens, fonts, license summary
- `LICENSE.txt` — your license terms (free tier)
- This README

## Personalize
Replace the showcase brand copy with your own, swap the palette tokens in `css/styles.css`
if you like, and keep the license footer line intact.

## License
ByJTT Free Template License: personal, non-commercial end products; attribution appreciated, not required.
Commercial use needs the Commercial license — https://byjtt-templates.pages.dev/licensing.html

## Support
https://github.com/jordan-thirkle/byjtt-web-design-templates/issues
